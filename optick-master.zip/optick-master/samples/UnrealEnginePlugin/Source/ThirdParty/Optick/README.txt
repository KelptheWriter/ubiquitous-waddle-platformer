Optick is a super-lightweight C++ profiler for Games.
It provides access for all the necessary tools required for efficient performance analysis and optimization:
instrumentation, switch-contexts, sampling, GPU counters.

https://github.com/bombomby/optick