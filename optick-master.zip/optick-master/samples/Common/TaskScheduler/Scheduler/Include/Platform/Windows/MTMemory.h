#pragma once

#ifndef __MT_MEMORY__
#define __MT_MEMORY__

#define MT_ALLOCATE_ON_STACK(BYTES_COUNT) _alloca(BYTES_COUNT)


#endif
