#pragma once

#ifndef __MT_COMMON__
#define __MT_COMMON__

#include "MTUtils.h"
#include "MTThread.h"
#include "MTMutex.h"
#include "MTAtomic.h"
#include "MTEvent.h"
#include "MTFiber.h"
#include "MTMemory.h"


#endif
