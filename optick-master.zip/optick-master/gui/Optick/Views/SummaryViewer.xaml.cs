﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Profiler.ViewModels;

namespace Profiler.Views
{
    /// <summary>
    /// Interaction logic for SummaryViewer.xaml
    /// </summary>
    public partial class SummaryViewer : UserControl
    {
        public SummaryViewer()
        {
            InitializeComponent();
        }
    }
}
