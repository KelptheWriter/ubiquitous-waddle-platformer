﻿using System.Windows.Controls;

namespace Profiler.Controls
{
	/// <summary>
	/// Interaction logic for CaptureThumbnail.xaml
	/// </summary>
	public partial class CaptureThumbnail : UserControl
	{
		public CaptureThumbnail()
		{
			InitializeComponent();
		}
	}
}
