﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Profiler.Trace
{
    public class Config
    {
        public IEnumerable<String> ProcessFilters { get; set; }
    }
}
